<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- SEO Meta Tags -->
    <meta name="description" content="Your description">
    <meta name="author" content="Your name">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on Facebook, Twitter, LinkedIn -->
	<meta property="og:site_name" content="" /> <!-- website name -->
	<meta property="og:site" content="" /> <!-- website link -->
	<meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
	<meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
	<meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
	<meta property="og:url" content="" /> <!-- where do you want your post to link to -->
	<meta name="twitter:card" content="summary_large_image"> <!-- to have large image post format in Twitter -->

    <!-- Webpage Title -->
    <title>Mirko - Broadband Company</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="mirko/css/bootstrap.min.css" rel="stylesheet">
    <link href="mirko/css/fontawesome-all.min.css" rel="stylesheet">
    <link href="mirko/css/aos.min.css" rel="stylesheet">
    <link href="mirko/css/swiper.css" rel="stylesheet">
    <link href="mirko/css/style.css" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="mirko/assets/images/favicon.png">
</head>
<body>
    
    <!-- Navigation -->
    <nav id="navbar" class="navbar navbar-expand-lg fixed-top navbar-dark" aria-label="Main navigation">
        <div class="container">

            <a class="navbar-brand logo-text" href="index.html">Mirko</a>

            <button class="navbar-toggler p-0 border-0" type="button" id="navbarSideCollapse" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault" >
                <ul class="navbar-nav ms-auto navbar-nav-scroll">
                </ul>
                <span class="nav-item social-icons">
                </span>
            </div> <!-- end of navbar-collapse -->
        </div> <!-- end of container -->
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->


    <!-- Home -->
    <section class="home py-5 d-flex align-items-center" id="header">
        <div class="container text-light py-5"  data-aos="fade-right"> 
            <h1 class="headline">Best <span class="home_text">Broadband</span><br>Internet Plans For You</h1>
            <p class="para para-light py-3">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Natus tempore accusamus quis magnam doloremque itaque ad modi, pariatur iste labore similique officiis impedit aspernatur aperiam facere architecto. Eligendi, repellendus inventore!</p>
            <div class="d-flex align-items-center">
                <p class="p-2"><i class="fas fa-laptop-house fa-lg"></i></p>
                <p>Lorem ipsum dolor sit amet.</p>  
            </div>
            <div class="d-flex align-items-center">
                <p class="p-2"><i class="fas fa-wifi fa-lg"></i></p>
                <p>Lorem ipsum dolor sit amet.</p>  
            </div>
            <div class="my-3">
                <a class="btn" href="/login">Log In</a>
            </div>
        </div> <!-- end of container -->
    </section> <!-- end of home -->
    
    <!-- Scripts -->
    <script src="mirko/js/bootstrap.min.js"></script><!-- Bootstrap framework -->
    <script src="mirko/js/purecounter.min.js"></script> <!-- Purecounter counter for statistics numbers -->
    <script src="mirko/js/swiper.min.js"></script><!-- Swiper for image and text sliders -->
    <script src="mirko/js/aos.js"></script><!-- AOS on Animation Scroll -->
    <script src="mirko/js/script.js"></script>  <!-- Custom scripts -->
</body>
</html><?php /**PATH C:\xampp\htdocs\00-Belajar\Learn-Laravel\zakat_fitrah\resources\views/home/index.blade.php ENDPATH**/ ?>