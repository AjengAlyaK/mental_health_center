<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/public">
    <?php echo $__env->make('show.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Kategori Mustahik</title>
</head>

<body class="nav-md ">
<div class="container body">
<div class="main_container">
<div class="col-md-3 left_col menu_fixed">
    <div class="left_col scroll-view">
    <div class="navbar nav_title" style="border: 0;">
        <a href="#" class="site_title"><span> Zakat Fitrah </span></a>
    </div>

    <div class="clearfix"></div>
    <!-- menu profile quick info -->
    <div class="profile clearfix">
        <div class="profile_pic">
        <img src="gentelella/production/images/admin2.jpg" alt="..." class="img-circle profile_img">
        </div>
        <div class="profile_info">
        <span>Welcome,</span>
        <h2>Admin</h2>
        </div>
    </div>
    <!-- /menu profile quick info -->

    <br />

    <!-- sidebar menu -->
    <?php echo $__env->make('show.sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /sidebar menu -->

    <!-- /menu footer buttons -->
    <!-- /menu footer buttons -->
    </div>
</div>

<!-- top navigation -->
<?php echo $__env->make('show.top_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /top navigation -->

<!-- page content -->

<?php echo $__env->make('show.data_kategori_mustahik', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- /page content -->


<!-- footer content -->
<!-- /footer content -->
</div>
</div>
<?php echo $__env->make('show.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp_old\htdocs\00-Belajar\Learn-Laravel\zakat_fitrah_217006056\resources\views/show/kategori_mustahik.blade.php ENDPATH**/ ?>