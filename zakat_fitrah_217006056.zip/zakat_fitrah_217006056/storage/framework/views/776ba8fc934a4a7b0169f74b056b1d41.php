<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/public">
	<title>Edit Kategori Mustahik</title>
    <?php echo $__env->make('show.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="nav-md footer_fixed">
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col menu_fixed">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="#" class="site_title"><span> Zakat Fitrah </span></a>
					</div>

					<div class="clearfix"></div>

					<!-- menu profile quick info -->
					<div class="profile clearfix">
						<div class="profile_pic">
						<img src="gentelella/production/images/admin2.jpg" alt="..." class="img-circle profile_img">
						</div>
						<div class="profile_info">
						<span>Welcome,</span>
						<h2>Admin</h2>
						</div>
					</div>
					<!-- /menu profile quick info -->

					<br />

					<!-- sidebar menu -->
					<?php echo $__env->make('show.sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- /sidebar menu -->

					<!-- /menu footer buttons -->
					<!-- /menu footer buttons -->
				</div>
			</div>

			<!-- top navigation -->
			<?php echo $__env->make('show.top_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /top navigation -->

			<!-- page content -->
			<div class="right_col" role="main">
				<div class="">
					<div class="page-title">
						<div class="title_left">
							<h3>Edit Kategori Mustahik</h3>
						</div>
					</div>
					<div class="clearfix"></div>
					<div class="row">
						<div class="col-md-12 col-sm-12 ">
							<div class="x_panel">
								<div class="x_title">
									<h2><a href="/kategori_mustahik" class="btn btn-secondary">Kembali</a></h2>
									
									<div class="clearfix"></div>
								</div>
								<div class="x_content">
									<?php if(session('status')): ?>
									<div class="alert alert-success alert-dismissible " role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
										</button>
										<strong><?php echo e(session('status')); ?></strong>
									</div>
									<?php endif; ?>
									<form action="/update_kategori_mustahik/<?php echo e($k_mustahik->id); ?>" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                                        <?php echo csrf_field(); ?>

										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="nama_kategori">Nama Kategori<span class="required"></span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="<?php echo e($k_mustahik->nama_kategori); ?>" name="nama_kategori" type="text" id="first-name" required="required" class="form-control ">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="jumlah_hak">Hak Beras<span></span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="<?php echo e($k_mustahik->jumlah_hak); ?>"" name="jumlah_hak" type="number" id="last-name" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="hak_uang">Hak Uang<span></span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="<?php echo e($k_mustahik->hak_uang); ?>"" name="hak_uang" type="number" id="hak_uang" class="form-control">
											</div>
										</div>
										<div class="ln_solid"></div>
										<div class="item form-group">
											<div class="col-md-6 col-sm-6 offset-md-3">
												<button type="submit" class="btn btn-primary">Edit</button>
											</div>
										</div>

									</form>
								</div>
							</div>
						</div>
					</div>

			<!-- /page content -->

			<!-- footer content -->
			
			<!-- /footer content -->
		</div>
	</div>

	<?php echo $__env->make('show.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body></html>
<?php /**PATH C:\xampp\htdocs\00-Belajar\Learn-Laravel\zakat_fitrah\resources\views/show/edit_kategori_mustahik.blade.php ENDPATH**/ ?>