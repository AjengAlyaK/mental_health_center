<!-- page content -->
<div class="right_col" role="main">
<div class="">
    <div class="page-title">
    <div class="title_left">
        <a href="/tambah_muzaki" class="btn btn-secondary">Tambah</a>
    </div>

    <div class="title_right">
        <div class="col-md-5 col-sm-5   form-group pull-right top_search">
        <div class="input-group">
            
        </div>
        </div>
    </div> 
    </div>
    
    <div class="clearfix"></div>

    <div class="row">
    <div class="col-md-12">
        <div class="x_panel">
        <div class="x_title">
            <h2>Data Muzaki</h2>
            <ul class="nav navbar-right panel_toolbox">
            
            </li>
            
            
            </li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible " role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
                <strong><?php echo e(session('status')); ?></strong>
            </div>
            <?php endif; ?>

            <!-- start project list -->
            <table class="table table-striped projects">
            <thead>
                <tr>
                <th style="width: 1%">#</th>
                <th style="width: 20%">Nama Muzaki</th>
                <th>Jumlah Tanggungan</th>
                <th>Keterangan</th>
                <th style="width: 20%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $muzaki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($m->nama_muzakki); ?></td>
                    <td><?php echo e($m->jumlah_tanggungan); ?></td>
                    <td><?php echo e($m->kategori_mustahik_id); ?></td>
                    <td>
                        
                        <!-- Trigger the modal with a button -->
                        <a href="/edit_data_muzaki/<?php echo e($m->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                        <a onclick="return confirm('Apakah data akan dihapus ?')" href="/delete_data_muzaki/<?php echo e($m->id); ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            <!-- end project list -->

        </div>
        </div>
    </div>
    </div>
</div>
</div>
<footer>
    <div class="pull-right">
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /page content --><?php /**PATH C:\xampp\htdocs\00-Belajar\Learn-Laravel\zakat_fitrah\resources\views/show/table.blade.php ENDPATH**/ ?>