<div id="sidebar-menu" class="main_menu_side hidden-print main_menu ">
    <div class="menu_section">
    <ul class="nav side-menu">
        <li><a href="/dashboard"><i class="fa fa-user"></i> Master Data Muzaki <span class="fa"></span></a>
        </li>
        <li><a href="/kategori_mustahik"><i class="fa fa-user"></i> Master Data Kategori Mustahik <span class="fa"></span></a>
        </li>
        <li><a href="/muzaki_sudah_bayar"><i class="fa fa-credit-card-alt"></i> Pengumpulan Zakat Fitrah <span class="fa"></span></a>
        </li>
        <li><a href="/warga_sudah_menerima_zakat"><i class="fa fa-share-alt"></i> Distribusi Zakat Fitrah Warga <span class="fa"></span></a>
        </li>
        <li><a href="/distribusi_zfm"><i class="fa fa-share-alt"></i> Distribusi Zakat Fitrah Mustahik<span class="fa"></span></a>
        </li>
        <li><a href="/laporan_pengumpulan"><i class="fa fa-file"></i> Laporan Pengumpulan Zakat Fitrah<span class="fa"></span></a>
        </li>
        <li><a href="/laporan_distribusi"><i class="fa fa-file"></i> Laporan Distribusi Zakat Fitrah<span class="fa"></span></a>
        </li>
    </ul>
    </div>

</div><?php /**PATH C:\xampp\htdocs\00-Belajar\Learn-Laravel\zakat_fitrah\resources\views/show/sidebar_menu.blade.php ENDPATH**/ ?>