<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('show.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Laporan Distribusi Zakat Fitrah</title>
</head>

<body class="nav-md ">
<div class="container body">
<div class="main_container">
<div class="col-md-3 left_col menu_fixed">
    <div class="left_col scroll-view">
    <div class="navbar nav_title" style="border: 0;">
        <a href="#" class="site_title"><span> Zakat Fitrah</span></a>
    </div>

    <div class="clearfix"></div>

    <!-- menu profile quick info -->
    <div class="profile clearfix">
        <div class="profile_pic">
        <img src="gentelella/production/images/admin2.jpg" alt="..." class="img-circle profile_img">
        </div>
        <div class="profile_info">
        <span>Welcome,</span>
        <h2>Admin</h2>
        </div>
    </div>
    <!-- /menu profile quick info -->

    <br />

    <!-- sidebar menu -->
    <?php echo $__env->make('show.sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /sidebar menu -->

    <!-- /menu footer buttons -->
    
    <!-- /menu footer buttons -->
    </div>
</div>

<!-- top navigation -->
<?php echo $__env->make('show.top_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /top navigation -->

<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
        <div class="title_left">
            <a href="/print-laporan-distribusi" class="btn btn-primary"><i class="fa fa-print" aria-hidden="true"></i> Print </a>
        </div>
    
        <div class="title_right">
            <div class="col-md-5 col-sm-5   form-group pull-right top_search">
            <div class="input-group">
                
            </div>
            </div>
        </div> 
        </div>
        
        <div class="clearfix"></div>
    
        <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
            <div class="x_title">
                <h2>Laporan Distribusi Zakat Fitrah</h2>
                <ul class="nav navbar-right panel_toolbox">
                
                </li>
                
                
                </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                
                <!-- start project list -->
                <table class="table table-striped projects">
                <thead>
                    <tr>
                    <th style="width: 1%">#</th>
                    <th style="width: 20%">Kategori Mustahik</th>
                    <th>Hak Beras</th>
                    <th>Hak Uang</th>
                    <th>Jumlah KK</th>
                    <th>Total Beras</th>
                    <th>Total Uang</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        <td>1</td>
                        <td><?php echo e($r1a); ?></td>
                        <td><?php echo e($r1b); ?></td>
                        <td><?php echo e($r1c); ?></td>
                        <td><?php echo e($r1d); ?></td>
                        <td><?php echo e($r1b * $r1d); ?></td>
                        <td><?php echo e($r1c * $r1d); ?></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td><?php echo e($r2a); ?></td>
                        <td><?php echo e($r2b); ?></td>
                        <td><?php echo e($r2c); ?></td>
                        <td><?php echo e($r2d); ?></td>
                        <td><?php echo e($r2b * $r2d); ?></td>
                        <td><?php echo e($r2c * $r2d); ?></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td><?php echo e($r3a); ?></td>
                        <td><?php echo e($r3b); ?></td>
                        <td><?php echo e($r3c); ?></td>
                        <td><?php echo e($r3d); ?></td>
                        <td><?php echo e($r3b * $r3d); ?></td>
                        <td><?php echo e($r3c * $r3d); ?></td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td><?php echo e($r5a); ?></td>
                        <td><?php echo e($r5b); ?></td>
                        <td><?php echo e($r5c); ?></td>
                        <td><?php echo e($r5d); ?></td>
                        <td><?php echo e($r5b * $r5d); ?></td>
                        <td><?php echo e($r5c * $r5d); ?></td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td><?php echo e($r6a); ?></td>
                        <td><?php echo e($r6b); ?></td>
                        <td><?php echo e($r6c); ?></td>
                        <td><?php echo e($r6d); ?></td>
                        <td><?php echo e($r6b * $r6d); ?></td>
                        <td><?php echo e($r6c * $r6d); ?></td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td><?php echo e($r7a); ?></td>
                        <td><?php echo e($r7b); ?></td>
                        <td><?php echo e($r7c); ?></td>
                        <td><?php echo e($r7d); ?></td>
                        <td><?php echo e($r7b * $r7d); ?></td>
                        <td><?php echo e($r7c * $r7d); ?></td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td><?php echo e($r8a); ?></td>
                        <td><?php echo e($r8b); ?></td>
                        <td><?php echo e($r8c); ?></td>
                        <td><?php echo e($r8d); ?></td>
                        <td><?php echo e($r8b * $r8d); ?></td>
                        <td><?php echo e($r8c * $r8d); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Total</td>
                        <td></td>
                        <td></td>
                        <td><?php echo e($r1d + $r2d + $r3d + $r5d + $r6d + $r7d + $r8d); ?></td>
                        <td><?php echo e(($r1b * $r1d)+($r2b * $r2d)+($r3b * $r3d)+($r5b * $r5d)+($r6b * $r6d)+($r7b * $r7d)+($r8b * $r8d)); ?></td>
                        <td><?php echo e(($r1c * $r1d)+($r2c * $r2d)+($r3c * $r3d)+($r5c * $r5d)+($r6c * $r6d)+($r7c * $r7d)+($r8c * $r8d)); ?></td>
                    </tr>
                </tbody>
                </table>
                <!-- end project list -->
    
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
    <footer>
        <div class="pull-right">
        </div>
        <div class="clearfix"></div>
    </footer>
<!-- /page content -->


<!-- footer content -->
<!-- /footer content -->
</div>
</div>
<?php echo $__env->make('show.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\00-Belajar\Learn-Laravel\zakat_fitrah\resources\views/show/laporan_distribusi.blade.php ENDPATH**/ ?>