<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <p><?php echo e(dd($muzaki_bayar)); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\00-Belajar\Learn-Laravel\zakat_fitrah\resources\views/show/list_muzaki_sudah_bayar.blade.php ENDPATH**/ ?>