<!DOCTYPE html>
<html lang="en">
<head>
	<base href="/public">
	<title>Bayar Zakat</title>
    @include('show.head')
</head>

<body class="nav-md footer_fixed">
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col menu_fixed">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="#" class="site_title"><span> Zakat Fitrah </span></a>
					</div>

					<div class="clearfix"></div>

					<!-- menu profile quick info -->
					<div class="profile clearfix">
						<div class="profile_pic">
						<img src="gentelella/production/images/admin2.jpg" alt="..." class="img-circle profile_img">
						</div>
						<div class="profile_info">
						<span>Welcome,</span>
						<h2>Admin</h2>
						</div>
					</div>
					<!-- /menu profile quick info -->

					<br />

					<!-- sidebar menu -->
					@include('show.sidebar_menu')
					<!-- /sidebar menu -->

					<!-- /menu footer buttons -->
					
					<!-- /menu footer buttons -->
				</div>
			</div>

			<!-- top navigation -->
			@include('show.top_nav')
            <!-- /top navigation -->

			<!-- page content -->
			<div class="right_col" role="main">
				<div class="">
					<div class="page-title">
						<div class="title_left">
							<h3>Pengumpulan Zakat Fitrah</h3>
						</div>
					</div>
					<div class="clearfix"></div>
					<div class="row">
						<div class="col-md-12 col-sm-12 ">
							<div class="x_panel">
								<div class="x_title">
									<h2><a href="/pengumpulan_zakat_fitrah" class="btn btn-secondary">Kembali</a></h2>
									<div class="clearfix"></div>
								</div>
								<div class="x_content">
									@if (session('status'))
									<div class="alert alert-success alert-dismissible " role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
										</button>
										<strong>{{session('status')}}</strong>
									</div>
									@endif
									<form action="/muzaki_bayar" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                                        @csrf

										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="muzakki_id">Muzakki Id<span class="required"></span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="{{$zakat->id}}" name="muzakki_id" type="text" id="muzakki_id" required="required" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="nama_KK">Nama KK<span class="required"></span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="{{$zakat->nama_muzakki}}" name="nama_KK" type="text" id="nama_KK" required="required" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label for="jumlah_tanggungan" class="col-form-label col-md-3 col-sm-3 label-align">Jumlah Tanggungan</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="{{$zakat->jumlah_tanggungan}}" name="jumlah_tanggungan" id="jumlah_tanggungan" class="form-control" type="number">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="jenis_bayar">Jenis Bayar<span class="required"></span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<select name="jenis_bayar" id="">
													<option value="bayar beras">Bayar Beras</option>
													<option value="bayar uang">Bayar Uang</option>
												</select></div>
											</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="jumlah_tanggunganyangdibayar">Jumlah Tanggungan yang Dibayar<span class="required"></span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="{{$zakat->jumlah_tanggungan}}" name="jumlah_tanggunganyangdibayar" type="number" id="jumlah_tanggunganyangdibayar" required="required" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label for="bayar_beras" class="col-form-label col-md-3 col-sm-3 label-align">Bayar Beras</label>
											<div class="col-md-6 col-sm-6 ">
												<input name="bayar_beras" id="bayar_beras" class="form-control" type="number">
											</div>
										</div>
										<div class="item form-group">
											<label for="bayar_uang" class="col-form-label col-md-3 col-sm-3 label-align">Bayar Uang</label>
											<div class="col-md-6 col-sm-6 ">
												<input name="bayar_uang" id="bayar_uang" class="form-control" type="number">
											</div>
										</div>
										
										<div class="item form-group">
											<label for="keterangan" class="col-form-label col-md-3 col-sm-3 label-align">Keterangan</label>
											<div class="col-md-6 col-sm-6 ">
												<input value="sudah mengumpulkan zakat" name="keterangan" id="keterangan" class="form-control" type="text">
											</div>
										</div>
										<div class="ln_solid"></div>
										<div class="item form-group">
											<div class="col-md-6 col-sm-6 offset-md-3">
												<button type="submit" class="btn btn-primary">Submit</button>
											</div>
										</div>

									</form>
								</div>
							</div>
						</div>
					</div>

			<!-- /page content -->

			<!-- footer content -->
			
			<!-- /footer content -->
		</div>
	</div>

	@include('show.script')
</body></html>
